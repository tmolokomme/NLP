All the folders goes to the GAC
All the files must be be added as references in your project. You would normally put them in bin directory of the project.